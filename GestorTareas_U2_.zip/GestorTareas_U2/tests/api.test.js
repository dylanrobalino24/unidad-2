'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../src/server');

let app, base, directory, dbPath, sessionCookie, csrf, task;

async function call(endpoint, { method = 'GET', data, cookie = sessionCookie, token = csrf, headers: extra = {} } = {}) {
  const headers = { ...extra };
  if (cookie) headers.Cookie = cookie;
  if (token) headers['X-CSRF-Token'] = token;
  if (data !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + endpoint, { method, headers, ...(data !== undefined ? { body: JSON.stringify(data) } : {}) });
  const body = response.status === 204 ? null : await response.json();
  return { response, body };
}

async function run() {
  directory = fs.mkdtempSync(path.join(os.tmpdir(), 'punto-u2-'));
  dbPath = path.join(directory, 'test.sqlite');
  app = createApp({ dbPath });
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${app.server.address().port}`;
}

test.before(run);
test.after(async () => {
  if (app) await app.close();
  if (directory) fs.rmSync(directory, { recursive: true, force: true });
});

test('01 - salud del servicio y archivos de la interfaz', async () => {
  const { response, body } = await call('/api/health');
  assert.equal(response.status, 200);
  assert.equal(body.data.status, 'ok');
  const page = await fetch(base + '/');
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Tablero de tareas/);
});

test('02 - las tareas exigen sesión activa', async () => {
  const { response, body } = await call('/api/tasks', { cookie: null, token: null });
  assert.equal(response.status, 401);
  assert.equal(body.error.code, 'SESSION_REQUIRED');
});

test('03 - nombre de sesión validado con error uniforme', async () => {
  const { response, body } = await call('/api/session', { method: 'POST', data: { name: 'a' }, cookie: null, token: null });
  assert.equal(response.status, 422);
  assert.equal(body.error.code, 'VALIDATION_ERROR');
});

test('04 - iniciar sesión crea cookie HttpOnly y token CSRF', async () => {
  const { response, body } = await call('/api/session', { method: 'POST', data: { name: 'Estudiante' }, cookie: null, token: null });
  assert.equal(response.status, 201);
  const setCookie = response.headers.get('set-cookie');
  assert.match(setCookie, /HttpOnly/);
  assert.match(setCookie, /SameSite=Strict/);
  sessionCookie = setCookie.split(';')[0];
  csrf = body.data.csrfToken;
  assert.equal(csrf.length, 64);
  const current = await call('/api/session');
  assert.equal(current.body.data.name, 'Estudiante');
});

test('05 - no se permiten escrituras sin CSRF', async () => {
  const { response, body } = await call('/api/tasks', { method: 'POST', data: { title: 'Sin protección' }, token: 'incorrecto' });
  assert.equal(response.status, 403);
  assert.equal(body.error.code, 'INVALID_CSRF');
});

test('06 - validar esquema y fecha imposible', async () => {
  for (const data of [{ title: 'X' }, { title: 'Fecha válida', dueDate: '2026-02-30' }, { title: 'Tarea válida', campoExtra: 3 }]) {
    const { response, body } = await call('/api/tasks', { method: 'POST', data });
    assert.equal(response.status, 422);
    assert.equal(body.error.code, 'VALIDATION_ERROR');
  }
});

test('07 - creación de tarea, estado 201, Location y ETag', async () => {
  const { response, body } = await call('/api/tasks', { method: 'POST', data: {
    title: 'Preparar presentación', description: 'Preparar diapositivas', priority: 'alta', dueDate: '2026-12-15'
  } });
  assert.equal(response.status, 201);
  assert.match(response.headers.get('location'), /^\/api\/tasks\/\d+$/);
  assert.equal(response.headers.get('etag'), '"1"');
  assert.equal(body.data.status, 'pendiente');
  task = body.data;
});

test('08 - conflicto por título duplicado sin distinguir mayúsculas', async () => {
  const { response, body } = await call('/api/tasks', { method: 'POST', data: { title: 'PREPARAR PRESENTACIÓN' } });
  assert.equal(response.status, 409);
  assert.equal(body.error.code, 'TASK_ALREADY_EXISTS');
});

test('09 - listado, consulta individual, filtros y paginación', async () => {
  const list = await call('/api/tasks?status=pendiente&limit=10&page=1');
  assert.equal(list.response.status, 200);
  assert.equal(list.body.meta.total, 1);
  assert.equal(list.body.data[0].title, task.title);
  const item = await call(`/api/tasks/${task.id}`);
  assert.equal(item.response.status, 200);
  assert.equal(item.response.headers.get('etag'), '"1"');
  const search = await call('/api/tasks?q=presentaci%C3%B3n');
  assert.equal(search.body.meta.total, 1);
  const injection = await call('/api/tasks?q=%25%27%20OR%201%3D1');
  assert.equal(injection.body.meta.total, 0);
  const summary = await call('/api/summary');
  assert.equal(summary.body.data.total, 1);
});

test('10 - PATCH requiere If-Match y permite edición parcial', async () => {
  const missing = await call(`/api/tasks/${task.id}`, { method: 'PATCH', data: { status: 'en_progreso' } });
  assert.equal(missing.response.status, 428);
  const updated = await call(`/api/tasks/${task.id}`, {
    method: 'PATCH', data: { status: 'en_progreso' }, headers: { 'If-Match': '"1"' }
  });
  assert.equal(updated.response.status, 200);
  assert.equal(updated.body.data.version, 2);
  assert.equal(updated.body.data.status, 'en_progreso');
  task = updated.body.data;
});

test('11 - evita modificaciones obsoletas con conflicto 409', async () => {
  const { response, body } = await call(`/api/tasks/${task.id}`, {
    method: 'PATCH', data: { priority: 'baja' }, headers: { 'If-Match': '"1"' }
  });
  assert.equal(response.status, 409);
  assert.equal(body.error.code, 'VERSION_CONFLICT');
  assert.equal(body.error.details.currentVersion, 2);
});

test('12 - PUT exige recurso completo y reemplaza los datos', async () => {
  const incomplete = await call(`/api/tasks/${task.id}`, {
    method: 'PUT', data: { title: 'Nuevo título' }, headers: { 'If-Match': '"2"' }
  });
  assert.equal(incomplete.response.status, 422);
  const valid = await call(`/api/tasks/${task.id}`, { method: 'PUT', headers: { 'If-Match': '"2"' }, data: {
    title: 'Terminar presentación', description: 'Preparar guion final', priority: 'media', status: 'completada', dueDate: null
  } });
  assert.equal(valid.response.status, 200);
  assert.equal(valid.body.data.version, 3);
  assert.equal(valid.body.data.dueDate, null);
  task = valid.body.data;
});

test('13 - SSE notifica la creación a una segunda sesión', async () => {
  const join = await call('/api/session', { method: 'POST', data: { name: 'Compañero' }, cookie: null, token: null });
  const otherCookie = join.response.headers.get('set-cookie').split(';')[0];
  const controller = new AbortController();
  const stream = await fetch(base + '/api/events', { headers: { Cookie: otherCookie }, signal: controller.signal });
  assert.equal(stream.status, 200);
  assert.match(stream.headers.get('content-type'), /text\/event-stream/);
  const reader = stream.body.getReader();
  const first = await reader.read();
  assert.match(Buffer.from(first.value).toString(), /event: ready/);
  const created = await call('/api/tasks', { method: 'POST', data: { title: 'Revisar resultados' } });
  assert.equal(created.response.status, 201);
  const deadline = setTimeout(() => controller.abort(), 4000);
  try {
    let received = '';
    while (!received.includes('event: task.created')) {
      const chunk = await reader.read();
      if (chunk.done) break;
      received += Buffer.from(chunk.value).toString();
    }
    assert.match(received, /event: task.created/);
    assert.match(received, /Revisar resultados/);
  } finally { clearTimeout(deadline); controller.abort(); }
});

test('14 - DELETE rechaza versiones anteriores y acepta la actual', async () => {
  const outdated = await call(`/api/tasks/${task.id}`, { method: 'DELETE', headers: { 'If-Match': '"1"' } });
  assert.equal(outdated.response.status, 409);
  const deleted = await call(`/api/tasks/${task.id}`, { method: 'DELETE', headers: { 'If-Match': '"3"' } });
  assert.equal(deleted.response.status, 204);
  const missing = await call(`/api/tasks/${task.id}`);
  assert.equal(missing.response.status, 404);
  assert.equal(missing.body.error.code, 'TASK_NOT_FOUND');
});

test('15 - SQLite conserva los datos al reabrir la base', async () => {
  const secondApp = createApp({ dbPath });
  await new Promise((resolve) => secondApp.server.listen(0, '127.0.0.1', resolve));
  const secondUrl = `http://127.0.0.1:${secondApp.server.address().port}`;
  try {
    const list = await fetch(secondUrl + '/api/tasks', { headers: { Cookie: sessionCookie } });
    assert.equal(list.status, 200);
    const data = await list.json();
    assert.equal(data.meta.total, 1);
    assert.equal(data.data[0].title, 'Revisar resultados');
  } finally { await secondApp.close(); }
});

test('16 - rutas inválidas, método 405 y JSON incorrecto', async () => {
  assert.equal((await call('/api/no-existe')).response.status, 404);
  const wrong = await call('/api/health', { method: 'POST' });
  assert.equal(wrong.response.status, 405);
  assert.equal(wrong.response.headers.get('allow'), 'GET');
  const malformed = await fetch(base + '/api/tasks', {
    method: 'POST', headers: { Cookie: sessionCookie, 'X-CSRF-Token': csrf, 'Content-Type': 'application/json' }, body: '{esto:no es json}'
  });
  assert.equal(malformed.status, 400);
  assert.equal((await malformed.json()).error.code, 'INVALID_JSON');
});

test('17 - ✓ y ✕ guardan colores como estados persistentes y pueden revertirse', async () => {
  const current = await call('/api/tasks?limit=10');
  assert.equal(current.body.data.length, 1);
  let item = current.body.data[0];
  const markDone = await call(`/api/tasks/${item.id}`, {
    method: 'PATCH', data: { status: 'completada' }, headers: { 'If-Match': `"${item.version}"` }
  });
  assert.equal(markDone.response.status, 200);
  assert.equal(markDone.body.data.status, 'completada');
  item = markDone.body.data;
  const doneList = await call('/api/tasks?status=completada');
  assert.equal(doneList.body.meta.total, 1);
  const markNo = await call(`/api/tasks/${item.id}`, {
    method: 'PATCH', data: { status: 'no_realizada' }, headers: { 'If-Match': `"${item.version}"` }
  });
  assert.equal(markNo.response.status, 200);
  assert.equal(markNo.body.data.status, 'no_realizada');
  item = markNo.body.data;
  const noList = await call('/api/tasks?status=no_realizada');
  assert.equal(noList.body.data[0].id, item.id);
  const summary = await call('/api/summary');
  assert.equal(summary.body.data.no_realizada, 1);
  const undo = await call(`/api/tasks/${item.id}`, {
    method: 'PATCH', data: { status: 'pendiente' }, headers: { 'If-Match': `"${item.version}"` }
  });
  assert.equal(undo.response.status, 200);
  assert.equal(undo.body.data.status, 'pendiente');
});

test('18 - migra esquema antiguo sin borrar tareas ni sesiones', async () => {
  const { DatabaseSync } = require('node:sqlite');
  const { connect } = require('../src/database');
  const oldPath = path.join(directory, 'legacy.sqlite');
  const old = new DatabaseSync(oldPath);
  old.exec(`
    CREATE TABLE tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL CHECK(length(title) BETWEEN 3 AND 100),
      title_key TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL CHECK(status IN ('pendiente', 'en_progreso', 'completada')),
      priority TEXT NOT NULL CHECK(priority IN ('baja', 'media', 'alta')),
      due_date TEXT, version INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE UNIQUE INDEX ux_tasks_title ON tasks(title_key);
    CREATE INDEX ix_tasks_status ON tasks(status);
    CREATE TABLE sessions (
      token_hash TEXT PRIMARY KEY, name TEXT NOT NULL, csrf_token TEXT NOT NULL,
      created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    INSERT INTO tasks VALUES (7, 'Tarea guardada', 'tarea guardada', 'Original', 'pendiente', 'alta', NULL, 4, '2026-01-01', '2026-01-02');
    INSERT INTO sessions VALUES ('hash-guardado', 'Ana', 'csrf', 1000, 9999999999999);
  `);
  old.close();
  const store = connect(oldPath);
  try {
    const oldTask = store.getTask(7);
    assert.equal(oldTask.title, 'Tarea guardada');
    assert.equal(oldTask.version, 4);
    assert.equal(store.findSession('hash-guardado', 2000).name, 'Ana');
    const updated = store.updateTask(7, 4, { status: 'no_realizada' });
    assert.equal(updated.status, 'no_realizada');
    assert.equal(store.summary().no_realizada, 1);
  } finally { store.close(); }
});

test('19 - cerrar sesión revoca la cookie', async () => {
  const bye = await call('/api/session', { method: 'DELETE' });
  assert.equal(bye.response.status, 204);
  const denied = await call('/api/tasks');
  assert.equal(denied.response.status, 401);
});
