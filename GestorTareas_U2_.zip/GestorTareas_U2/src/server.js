'use strict';

const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs/promises');
const crypto = require('node:crypto');
const { connect } = require('./database');
const { validateTask, validateName, validateFilters, positiveInt } = require('./validation');
const { HttpError, fail } = require('./errors');

const COOKIE = 'u2_session';
const SESSION_DURATION = 24 * 60 * 60 * 1000;
const MAX_BODY = 32 * 1024;
const ASSETS = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/favicon.svg': ['favicon.svg', 'image/svg+xml']
};

function json(res, status, payload, moreHeaders = {}) {
  const body = payload === undefined ? '' : JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
    ...moreHeaders
  });
  res.end(body);
}

function secureHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
}

function tokenHash(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function tokenFromRequest(req) {
  const cookies = (req.headers.cookie || '').split(';');
  for (const item of cookies) {
    const index = item.indexOf('=');
    if (index < 0 || item.slice(0, index).trim() !== COOKIE) continue;
    const token = item.slice(index + 1).trim();
    return /^[a-f0-9]{64}$/.test(token) ? token : null;
  }
  return null;
}

function sessionOf(req, store) {
  const token = tokenFromRequest(req);
  return token ? store.findSession(tokenHash(token), Date.now()) : null;
}

function mustSession(req, store) {
  const session = sessionOf(req, store);
  if (!session) fail(401, 'SESSION_REQUIRED', 'Inicia una sesión de trabajo para continuar.');
  return session;
}

function mustCsrf(req, session) {
  const header = req.headers['x-csrf-token'];
  if (typeof header !== 'string' || header.length !== session.csrf_token.length ||
    !crypto.timingSafeEqual(Buffer.from(header), Buffer.from(session.csrf_token))) {
    fail(403, 'INVALID_CSRF', 'Token de protección no válido. Recarga la página.');
  }
}

function checkOrigin(req) {
  if (!req.headers.origin) return;
  let origin;
  try { origin = new URL(req.headers.origin); } catch { fail(403, 'INVALID_ORIGIN', 'Origen no válido.'); }
  if (origin.host !== req.headers.host) fail(403, 'INVALID_ORIGIN', 'Origen no permitido.');
}

async function readBody(req) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) {
    fail(415, 'UNSUPPORTED_MEDIA_TYPE', 'Envía Content-Type: application/json.');
  }
  let size = 0;
  const parts = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) fail(413, 'BODY_TOO_LARGE', 'El JSON supera los 32 KB permitidos.');
    parts.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(parts).toString('utf8')); }
  catch { fail(400, 'INVALID_JSON', 'El cuerpo no contiene JSON válido.'); }
}

function matchId(pathname) {
  const m = /^\/api\/tasks\/([^/]+)$/.exec(pathname);
  if (!m) return null;
  return positiveInt(m[1], 'id');
}

function ifMatch(req) {
  const h = req.headers['if-match'];
  if (typeof h !== 'string') fail(428, 'PRECONDITION_REQUIRED', 'Envía If-Match con la versión de la tarea.');
  const match = /^"?([1-9]\d*)"?$/.exec(h);
  if (!match) fail(400, 'INVALID_IF_MATCH', 'If-Match debe contener una versión numérica, por ejemplo "1".');
  return positiveInt(match[1], 'If-Match');
}

function methodNotAllowed(res, allowed) {
  fail(405, 'METHOD_NOT_ALLOWED', `Método no permitido. Usa ${allowed.join(', ')}.`, { allow: allowed });
}

function createApp(options = {}) {
  const databasePath = options.dbPath || path.join(__dirname, '..', 'data', 'tareas.sqlite');
  const publicDir = options.publicDir || path.join(__dirname, '..', 'public');
  const store = connect(databasePath);
  const listeners = new Set();
  let eventId = 0;

  function emit(type, task, actor) {
    const message = `id: ${++eventId}\nevent: ${type}\ndata: ${JSON.stringify({ task, actor, type })}\n\n`;
    for (const res of listeners) {
      if (!res.destroyed) res.write(message);
    }
  }

  const server = http.createServer(async (req, res) => {
    secureHeaders(res);
    try {
      const url = new URL(req.url, 'http://localhost');
      const pathname = url.pathname;
      const method = req.method;

      if (ASSETS[pathname]) {
        if (method !== 'GET' && method !== 'HEAD') return methodNotAllowed(res, ['GET', 'HEAD']);
        const [filename, mime] = ASSETS[pathname];
        const file = await fs.readFile(path.join(publicDir, filename));
        res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-cache' });
        return res.end(method === 'HEAD' ? undefined : file);
      }

      if (pathname === '/api/health') {
        if (method !== 'GET') return methodNotAllowed(res, ['GET']);
        return json(res, 200, { data: { status: 'ok', service: 'gestor-tareas-u2' } });
      }

      if (pathname === '/api/session') {
        if (method === 'GET') {
          const session = sessionOf(req, store);
          return json(res, 200, { data: session ? { name: session.name, csrfToken: session.csrf_token, expiresAt: new Date(session.expires_at).toISOString() } : null });
        }
        if (method === 'POST') {
          checkOrigin(req);
          const name = validateName(await readBody(req));
          const token = crypto.randomBytes(32).toString('hex');
          const csrf = crypto.randomBytes(32).toString('hex');
          const now = Date.now();
          const prior = tokenFromRequest(req);
          if (prior) store.deleteSession(tokenHash(prior));
          store.createSession(tokenHash(token), name, csrf, now, now + SESSION_DURATION);
          const secure = process.env.COOKIE_SECURE === '1' ? '; Secure' : '';
          return json(res, 201, { data: { name, csrfToken: csrf, expiresAt: new Date(now + SESSION_DURATION).toISOString() } },
            { 'Set-Cookie': `${COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${secure}` });
        }
        if (method === 'DELETE') {
          checkOrigin(req);
          const session = mustSession(req, store);
          mustCsrf(req, session);
          const token = tokenFromRequest(req);
          store.deleteSession(tokenHash(token));
          return json(res, 204, undefined, { 'Set-Cookie': `${COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0` });
        }
        return methodNotAllowed(res, ['GET', 'POST', 'DELETE']);
      }

      if (pathname === '/api/events') {
        if (method !== 'GET') return methodNotAllowed(res, ['GET']);
        mustSession(req, store);
        if (listeners.size >= 100) fail(503, 'TOO_MANY_CLIENTS', 'Límite de conexiones en tiempo real alcanzado.');
        res.writeHead(200, {
          'Content-Type': 'text/event-stream; charset=utf-8',
          'Cache-Control': 'no-cache, no-transform',
          Connection: 'keep-alive',
          'X-Accel-Buffering': 'no'
        });
        res.write('retry: 2000\nevent: ready\ndata: {"connected":true}\n\n');
        listeners.add(res);
        const heartbeat = setInterval(() => { if (!res.destroyed) res.write(': latido\n\n'); }, 25000);
        const clean = () => { listeners.delete(res); clearInterval(heartbeat); };
        req.on('close', clean);
        res.on('close', clean);
        return;
      }

      if (pathname === '/api/summary') {
        if (method !== 'GET') return methodNotAllowed(res, ['GET']);
        mustSession(req, store);
        return json(res, 200, { data: store.summary() });
      }

      if (pathname === '/api/tasks') {
        const session = mustSession(req, store);
        if (method === 'GET') return json(res, 200, store.list(validateFilters(url.searchParams)));
        if (method === 'POST') {
          checkOrigin(req);
          mustCsrf(req, session);
          const created = store.createTask(validateTask(await readBody(req)));
          emit('task.created', created, session.name);
          return json(res, 201, { data: created }, { Location: `/api/tasks/${created.id}`, ETag: `"${created.version}"` });
        }
        return methodNotAllowed(res, ['GET', 'POST']);
      }

      if (pathname.startsWith('/api/tasks/')) {
        const id = matchId(pathname);
        if (id === null) fail(404, 'NOT_FOUND', 'Ruta no encontrada.');
        const session = mustSession(req, store);
        if (method === 'GET') {
          const task = store.getTask(id);
          if (!task) fail(404, 'TASK_NOT_FOUND', 'La tarea no existe.');
          return json(res, 200, { data: task }, { ETag: `"${task.version}"` });
        }
        if (method === 'PUT' || method === 'PATCH') {
          checkOrigin(req);
          mustCsrf(req, session);
          const expected = ifMatch(req);
          const input = validateTask(await readBody(req), method === 'PUT' ? 'replace' : 'patch');
          const updated = store.updateTask(id, expected, input);
          emit('task.updated', updated, session.name);
          return json(res, 200, { data: updated }, { ETag: `"${updated.version}"` });
        }
        if (method === 'DELETE') {
          checkOrigin(req);
          mustCsrf(req, session);
          const deleted = store.deleteTask(id, ifMatch(req));
          emit('task.deleted', deleted, session.name);
          return json(res, 204);
        }
        return methodNotAllowed(res, ['GET', 'PUT', 'PATCH', 'DELETE']);
      }
      fail(404, 'NOT_FOUND', 'Ruta no encontrada.');
    } catch (error) {
      if (res.headersSent) {
        res.destroy();
        return;
      }
      if (error instanceof HttpError) {
        const headers = error.status === 405 ? { Allow: error.details.allow.join(', ') } : {};
        return json(res, error.status, {
          error: { code: error.code, message: error.message, ...(error.details && error.status !== 405 ? { details: error.details } : {}) }
        }, headers);
      }
      console.error('Error interno:', error);
      return json(res, 500, { error: { code: 'INTERNAL_ERROR', message: 'Error interno del servidor.' } });
    }
  });

  return {
    server,
    close() {
      for (const res of listeners) res.end();
      listeners.clear();
      return new Promise((resolve, reject) => {
        server.close((err) => {
          store.close();
          if (err && err.code !== 'ERR_SERVER_NOT_RUNNING') reject(err);
          else resolve();
        });
      });
    }
  };
}

if (require.main === module) {
  const port = Number(process.env.PORT || 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT no válido');
  const app = createApp();
  app.server.listen(port, '127.0.0.1', () => {
    console.log(`Gestor de tareas disponible en http://localhost:${port}`);
  });
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.once(sig, () => app.close().then(() => process.exit(0)).catch(() => process.exit(1)));
  }
}

module.exports = { createApp };
