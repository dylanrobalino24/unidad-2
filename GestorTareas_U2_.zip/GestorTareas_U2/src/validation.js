'use strict';

const { fail } = require('./errors');
const STATUSES = ['pendiente', 'en_progreso', 'completada', 'no_realizada'];
const PRIORITIES = ['baja', 'media', 'alta'];
const FIELDS = ['title', 'description', 'status', 'priority', 'dueDate'];

function rejectExtraKeys(value, allowed) {
  const unknown = Object.keys(value).filter((key) => !allowed.includes(key));
  if (unknown.length) fail(422, 'VALIDATION_ERROR', 'Se encontraron campos no permitidos.', { fields: unknown });
}

function object(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    fail(422, 'VALIDATION_ERROR', 'El cuerpo debe ser un objeto JSON.');
  }
  return value;
}

function text(value, field, min, max) {
  if (typeof value !== 'string') fail(422, 'VALIDATION_ERROR', `El campo ${field} debe ser texto.`);
  const clean = value.trim();
  if (clean.length < min || clean.length > max) {
    fail(422, 'VALIDATION_ERROR', `El campo ${field} debe tener entre ${min} y ${max} caracteres.`);
  }
  return clean;
}

function optionalDescription(value) {
  if (value === null) return '';
  return text(value, 'description', 0, 500);
}

function enumValue(value, field, options) {
  if (!options.includes(value)) fail(422, 'VALIDATION_ERROR', `${field} debe ser: ${options.join(', ')}.`);
  return value;
}

function dueDate(value) {
  if (value === null || value === '') return null;
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    fail(422, 'VALIDATION_ERROR', 'dueDate debe ser una fecha YYYY-MM-DD o null.');
  }
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    fail(422, 'VALIDATION_ERROR', 'dueDate no es una fecha válida.');
  }
  return value;
}

function validateTask(value, mode = 'create') {
  object(value);
  rejectExtraKeys(value, FIELDS);
  if (mode !== 'patch' && !Object.hasOwn(value, 'title')) {
    fail(422, 'VALIDATION_ERROR', 'title es obligatorio.');
  }
  if (mode === 'patch' && Object.keys(value).length === 0) {
    fail(422, 'VALIDATION_ERROR', 'Debes enviar al menos un campo para actualizar.');
  }
  const result = {};
  if (mode === 'create') {
    result.description = '';
    result.status = 'pendiente';
    result.priority = 'media';
    result.dueDate = null;
  }
  if (Object.hasOwn(value, 'title')) result.title = text(value.title, 'title', 3, 100);
  if (Object.hasOwn(value, 'description')) result.description = optionalDescription(value.description);
  if (Object.hasOwn(value, 'status')) result.status = enumValue(value.status, 'status', STATUSES);
  if (Object.hasOwn(value, 'priority')) result.priority = enumValue(value.priority, 'priority', PRIORITIES);
  if (Object.hasOwn(value, 'dueDate')) result.dueDate = dueDate(value.dueDate);
  if (mode === 'replace' && FIELDS.some((field) => !Object.hasOwn(value, field))) {
    fail(422, 'VALIDATION_ERROR', 'PUT exige title, description, status, priority y dueDate.');
  }
  return result;
}

function validateName(value) {
  object(value);
  rejectExtraKeys(value, ['name']);
  const name = text(value.name, 'name', 2, 32);
  if (/[<>\x00-\x1F]/.test(name)) fail(422, 'VALIDATION_ERROR', 'El nombre contiene caracteres no permitidos.');
  return name;
}

function positiveInt(value, label) {
  if (!/^[1-9]\d*$/.test(String(value))) {
    fail(400, 'INVALID_PARAMETER', `${label} debe ser un entero positivo.`);
  }
  const number = Number(value);
  if (!Number.isSafeInteger(number)) fail(400, 'INVALID_PARAMETER', `${label} no es válido.`);
  return number;
}

function validateFilters(params) {
  const allowed = ['status', 'q', 'page', 'limit'];
  for (const key of params.keys()) {
    if (!allowed.includes(key) || params.getAll(key).length > 1) {
      fail(400, 'INVALID_PARAMETER', `Parámetro no admitido o duplicado: ${key}.`);
    }
  }
  const status = params.get('status') || 'todas';
  if (status !== 'todas' && !STATUSES.includes(status)) {
    fail(400, 'INVALID_PARAMETER', 'Filtro status no válido.');
  }
  const q = (params.get('q') || '').trim();
  if (q.length > 80) fail(400, 'INVALID_PARAMETER', 'La búsqueda no puede superar 80 caracteres.');
  const page = positiveInt(params.get('page') || '1', 'page');
  const limit = positiveInt(params.get('limit') || '50', 'limit');
  if (page > 100000 || limit > 100) fail(400, 'INVALID_PARAMETER', 'Fuera del rango de paginación.');
  return { status, q, page, limit };
}

module.exports = { validateTask, validateName, validateFilters, positiveInt };
