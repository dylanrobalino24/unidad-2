'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { fail } = require('./errors');

function toTask(row) {
  if (!row) return null;
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    status: row.status,
    priority: row.priority,
    dueDate: row.due_date,
    version: row.version,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function titleKey(title) { return title.normalize('NFKC').toLocaleLowerCase('es'); }

function connect(dbPath) {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL CHECK(length(title) BETWEEN 3 AND 100),
      title_key TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL CHECK(status IN ('pendiente', 'en_progreso', 'completada', 'no_realizada')),
      priority TEXT NOT NULL CHECK(priority IN ('baja', 'media', 'alta')),
      due_date TEXT,
      version INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS ux_tasks_title ON tasks(title_key);
    CREATE INDEX IF NOT EXISTS ix_tasks_status ON tasks(status);
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      csrf_token TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );
  `);
  // Una base creada con la versión anterior restringe el estado mediante CHECK.
  // Migración transaccional: conserva tareas, IDs, versiones y sesiones existentes.
  const definition = db.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'tasks'").get().sql;
  if (!definition.includes("'no_realizada'")) {
    try {
      db.exec(`
        BEGIN IMMEDIATE;
        CREATE TABLE tasks_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL CHECK(length(title) BETWEEN 3 AND 100),
          title_key TEXT NOT NULL,
          description TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL CHECK(status IN ('pendiente', 'en_progreso', 'completada', 'no_realizada')),
          priority TEXT NOT NULL CHECK(priority IN ('baja', 'media', 'alta')),
          due_date TEXT,
          version INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        INSERT INTO tasks_new (id,title,title_key,description,status,priority,due_date,version,created_at,updated_at)
          SELECT id,title,title_key,description,status,priority,due_date,version,created_at,updated_at FROM tasks;
        DROP TABLE tasks;
        ALTER TABLE tasks_new RENAME TO tasks;
        CREATE UNIQUE INDEX ux_tasks_title ON tasks(title_key);
        CREATE INDEX ix_tasks_status ON tasks(status);
        COMMIT;
      `);
    } catch (error) {
      if (db.inTransaction) db.exec('ROLLBACK;');
      db.close();
      throw error;
    }
  }
  if (dbPath !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');

  const get = db.prepare('SELECT * FROM tasks WHERE id = ?');
  const insert = db.prepare(`INSERT INTO tasks
    (title, title_key, description, status, priority, due_date, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  const update = db.prepare(`UPDATE tasks SET title = ?, title_key = ?, description = ?, status = ?, priority = ?,
    due_date = ?, updated_at = ?, version = version + 1 WHERE id = ? AND version = ?`);
  const remove = db.prepare('DELETE FROM tasks WHERE id = ? AND version = ?');
  const getSession = db.prepare('SELECT * FROM sessions WHERE token_hash = ? AND expires_at > ?');
  const insertSession = db.prepare('INSERT INTO sessions VALUES (?, ?, ?, ?, ?)');
  const removeSession = db.prepare('DELETE FROM sessions WHERE token_hash = ?');

  return {
    db,
    close: () => db.close(),
    getTask(id) { return toTask(get.get(id)); },
    list({ status, q, page, limit }) {
      const filters = [];
      const values = [];
      if (status !== 'todas') {
        filters.push('status = ?');
        values.push(status);
      }
      if (q) {
        filters.push("(title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\')");
        const term = `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
        values.push(term, term);
      }
      const where = filters.length ? ` WHERE ${filters.join(' AND ')}` : '';
      const total = db.prepare(`SELECT COUNT(*) AS amount FROM tasks${where}`).get(...values).amount;
      const rows = db.prepare(`SELECT * FROM tasks${where} ORDER BY updated_at DESC, id DESC LIMIT ? OFFSET ?`)
        .all(...values, limit, (page - 1) * limit);
      return { data: rows.map(toTask), meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
    },
    summary() {
      const rows = db.prepare('SELECT status, COUNT(*) AS amount FROM tasks GROUP BY status').all();
      const counts = { pendiente: 0, en_progreso: 0, completada: 0, no_realizada: 0, total: 0 };
      for (const row of rows) {
        counts[row.status] = row.amount;
        counts.total += row.amount;
      }
      return counts;
    },
    createTask(input) {
      const now = new Date().toISOString();
      try {
        const result = insert.run(input.title, titleKey(input.title), input.description, input.status, input.priority, input.dueDate, now, now);
        return toTask(get.get(Number(result.lastInsertRowid)));
      } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
          fail(409, 'TASK_ALREADY_EXISTS', 'Ya existe una tarea con ese título.');
        }
        throw error;
      }
    },
    updateTask(id, expectedVersion, patch) {
      const old = get.get(id);
      if (!old) fail(404, 'TASK_NOT_FOUND', 'La tarea no existe.');
      if (old.version !== expectedVersion) fail(409, 'VERSION_CONFLICT', 'La tarea cambió. Actualiza la lista antes de editar.', { currentVersion: old.version });
      const merged = { ...toTask(old), ...patch };
      try {
        const result = update.run(merged.title, titleKey(merged.title), merged.description, merged.status, merged.priority,
          merged.dueDate, new Date().toISOString(), id, expectedVersion);
        if (result.changes !== 1) fail(409, 'VERSION_CONFLICT', 'Conflicto de edición.');
        return toTask(get.get(id));
      } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
          fail(409, 'TASK_ALREADY_EXISTS', 'Ya existe una tarea con ese título.');
        }
        throw error;
      }
    },
    deleteTask(id, expectedVersion) {
      const old = get.get(id);
      if (!old) fail(404, 'TASK_NOT_FOUND', 'La tarea no existe.');
      if (old.version !== expectedVersion) fail(409, 'VERSION_CONFLICT', 'La tarea cambió. Actualiza la lista antes de eliminar.', { currentVersion: old.version });
      if (remove.run(id, expectedVersion).changes !== 1) fail(409, 'VERSION_CONFLICT', 'Conflicto al eliminar.');
      return toTask(old);
    },
    createSession(tokenHash, name, csrfToken, createdAt, expiresAt) {
      db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(createdAt);
      insertSession.run(tokenHash, name, csrfToken, createdAt, expiresAt);
    },
    findSession(tokenHash, now) { return getSession.get(tokenHash, now) || null; },
    deleteSession(tokenHash) { removeSession.run(tokenHash); }
  };
}

module.exports = { connect };
