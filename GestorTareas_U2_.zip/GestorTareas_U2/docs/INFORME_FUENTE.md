# Informe técnico - API REST «Punto»

**Universidad Politécnica Salesiana**  
**Asignatura:** Aplicaciones Web  
**Unidad:** 2. Programación del lado del servidor  
**Estudiante:** [Apellido y nombre]  
**Fecha:** 1 de noviembre de 2026

## 1. Objetivo y resultado

Se desarrolló «Punto», un gestor colaborativo de tareas accesible desde el navegador. La aplicación ofrece una API REST para crear, listar, consultar, reemplazar, actualizar parcialmente y eliminar tareas. La interfaz presenta una lista de tareas con controles ✓ (realizada) y ✕ (no realizada). El título cambia a verde o rojo y la elección persiste en SQLite; es reversible. También conserva los estados pendiente y en progreso, búsqueda, filtros y conteos, además de sincronización de sesiones en tiempo real.

## 2. Arquitectura y diseño HTTP

El servidor utiliza Node.js con su módulo `http` como tecnología equivalente a Express, sin dependencias externas. La estructura separa rutas y E/S (`src/server.js`), acceso a SQLite (`src/database.js`), transformaciones y validaciones puras (`src/validation.js`) y errores (`src/errors.js`). La interfaz se compone de HTML semántico, CSS adaptable y JavaScript con `fetch` y `EventSource`.

| Operación | Ruta | Código exitoso |
|---|---|---|
| Estado del servicio | GET `/api/health` | 200 |
| Sesión | GET/POST/DELETE `/api/session` | 200/201/204 |
| Resumen | GET `/api/summary` | 200 |
| Listar y crear | GET/POST `/api/tasks` | 200/201 |
| Consultar, sustituir, editar y borrar | GET/PUT/PATCH/DELETE `/api/tasks/:id` | 200/200/200/204 |
| Eventos | GET `/api/events` | 200 (SSE) |

Las respuestas JSON son uniformes. Ejemplo: `POST /api/tasks` con `{ "title": "Preparar exposición", "priority": "alta" }` devuelve 201, `Location`, `ETag` y `{ "data": { ... } }`. Los errores siguen `{ "error": { "code": "...", "message": "..." } }`. El listado admite paginación, búsqueda y filtro por estado.

## 3. Persistencia, validación y conflictos

SQLite crea automáticamente las tablas `tasks` y `sessions`; la migración transaccional incorpora el nuevo estado sin borrar registros antiguos. Cada tarea almacena título, descripción, estado, prioridad, fecha límite, fechas de creación/edición y `version`. Las consultas emplean parámetros enlazados para evitar inyección SQL. La validación comprueba tipos, longitud, enumeraciones, fechas reales, nombres de sesión y campos permitidos. Un índice único para el título normalizado detecta duplicados (409).

Las operaciones PUT, PATCH y DELETE requieren `If-Match: "<versión>"`; cada actualización incrementa `version`. Una versión desactualizada devuelve 409 `VERSION_CONFLICT`, evitando sobrescrituras silenciosas. Cuando falta `If-Match` se devuelve 428. Otros códigos incluyen 400, 401, 403, 404, 405, 413, 415 y 422.

## 4. Sesiones y tiempo real

La sesión de trabajo dura 24 horas. Se entrega una cookie aleatoria `HttpOnly; SameSite=Strict`, se guarda su hash SHA-256 y se exige un token CSRF para escrituras. El nombre de sesión **no representa autenticación por contraseña**. El tablero es compartido y el servidor escucha solo en localhost.

Con **Server-Sent Events (SSE)**, `GET /api/events` mantiene una conexión abierta y emite `task.created`, `task.updated` y `task.deleted` con la tarea y el actor. En el navegador, `EventSource` recibe el evento y vuelve a consultar los recursos para mantener el tablero sincronizado.

## 5. Pruebas y reproducibilidad

Se ejecutaron **19 pruebas automatizadas y las 19 aprobaron (0 fallos)** con `node --test`. Se validaron rutas, sesión/cookie, CSRF, JSON incorrecto, fechas inválidas, creación, duplicados, listado, consulta, filtro, PATCH, PUT, conflicto 409, borrado, SSE entre dos sesiones, persistencia al reabrir SQLite, marcas ✓/✕ reversibles, migración de una base previa y cierre de sesión. Evidencia: `evidencias/resultado-pruebas.txt`. La colección Postman y los ejemplos se encuentran en `docs/`.

Para reproducir: instalar Node.js 22.13+, descomprimir el proyecto, ejecutar `npm start`, abrir `http://localhost:3000` y crear tareas. Ejecutar `npm test` para repetir las pruebas. La base se crea en `data/tareas.sqlite`. No se necesita `npm install`.

## 6. Entrega y bibliografía

**Repositorio:** [URL del repositorio - pendiente de publicar]  
**Demostración local:** `http://localhost:3000` (solo accesible con el servidor ejecutándose).  
**URL pública de demostración:** [URL pública - si corresponde].

**Bibliografía del enunciado (APA):** Brown, E. (2020). *Web Development with Node & Express* (2.ª ed.). O’Reilly Media. Duckett, J. (2014). *JavaScript & jQuery: Interactive Front-End Web Development*. Wiley. Robbins, J. N. (2018). *Learning Web Design* (5.ª ed.). O’Reilly Media.

**Nota de alcance:** la solución está orientada a uso académico/local; antes de exponerla a Internet debe incorporarse autenticación, TLS, controles antiabuso y un despliegue apropiado.
