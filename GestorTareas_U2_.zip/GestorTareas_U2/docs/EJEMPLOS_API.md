# Contrato de la API REST y ejemplos reproducibles

URL base local: `http://localhost:3000`. Formato de las peticiones: `application/json`. Respuestas exitosas: `{ "data": ... }`, salvo el listado (`data` y `meta`) o los `204` vacíos. Errores: `{ "error": { "code": "CÓDIGO", "message": "Descripción", "details": {} } }`; el atributo `details` solo aparece cuando aporta información.

## 1. Crear sesión (201)

```http
POST /api/session HTTP/1.1
Content-Type: application/json

{"name":"Estudiante"}
```

Respuesta de ejemplo:

```json
{"data":{"name":"Estudiante","csrfToken":"<TOKEN_CSRF_GENERADO>","expiresAt":"<FECHA_ISO_GENERADA>"}}
```

La cabecera `Set-Cookie` incorpora `u2_session=<TOKEN_ALEATORIO>; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`.
Guarda la cookie y `csrfToken`: las operaciones `POST`, `PUT`, `PATCH` y `DELETE` sobre tareas exigen `X-CSRF-Token`. **No reemplaces el token por el texto de ejemplo.**

`GET /api/session` devuelve información de la sesión activa, o `{"data":null}` cuando no hay sesión. `DELETE /api/session` la revoca (204).

## 2. Crear tarea (201)

```http
POST /api/tasks HTTP/1.1
Content-Type: application/json
Cookie: u2_session=<COOKIE_REAL>
X-CSRF-Token: <TOKEN_CSRF_REAL>

{"title":"Preparar exposición","description":"Revisar las diapositivas","status":"pendiente","priority":"alta","dueDate":"2026-12-15"}
```

Respuesta de ejemplo (ID, fecha y versión son valores generados):

```json
{
  "data": {
    "id": 1,
    "title": "Preparar exposición",
    "description": "Revisar las diapositivas",
    "status": "pendiente",
    "priority": "alta",
    "dueDate": "2026-12-15",
    "version": 1,
    "createdAt": "<FECHA_ISO_GENERADA>",
    "updatedAt": "<FECHA_ISO_GENERADA>"
  }
}
```

Cabeceras: `Location: /api/tasks/1` y `ETag: "1"`.

El título es obligatorio y debe tener 3-100 caracteres. La descripción permite 0-500. Estados permitidos: `pendiente`, `en_progreso`, `completada`, `no_realizada`. Prioridades: `baja`, `media`, `alta`. Fecha opcional: `YYYY-MM-DD` o `null`.

## 3. Listar, filtrar y buscar (200)

```http
GET /api/tasks?status=pendiente&q=exposici%C3%B3n&page=1&limit=10
```

Responde con `data: [<TAREAS>]` y `meta: { "page": 1, "limit": 10, "total": 1, "totalPages": 1 }` (el total depende del contenido). El texto de búsqueda emplea parámetros SQL seguros. También existe `GET /api/tasks/1` (200 y `ETag`) y `GET /api/summary` (total y conteos por estado).

## 4. Actualizar una parte (200)

```http
PATCH /api/tasks/1 HTTP/1.1
Content-Type: application/json
Cookie: u2_session=<COOKIE_REAL>
X-CSRF-Token: <TOKEN_CSRF_REAL>
If-Match: "1"

{"status":"en_progreso"}
```

Responde con el recurso actualizado y `version: 2`, `ETag: "2"`. Si el registro ya cambió, la API responde **409**:

```json
{"error":{"code":"VERSION_CONFLICT","message":"La tarea cambió. Actualiza la lista antes de editar.","details":{"currentVersion":2}}}
```

`PUT /api/tasks/1` usa las mismas cabeceras, pero exige los cinco campos: `title`, `description`, `status`, `priority`, `dueDate`.

### Marcar ✓ o ✕ desde la interfaz (200)

Al pulsar **✓** la página realiza `PATCH /api/tasks/:id` con `{"status":"completada"}`; al pulsar **✕** utiliza `{"status":"no_realizada"}`. Los cambios se persisten en SQLite y emiten `task.updated` a las demás sesiones. La misma casilla pulsada de nuevo envía `{"status":"pendiente"}`. Las cabeceras `If-Match` y `X-CSRF-Token` siguen siendo obligatorias. El título aparece verde o rojo según el estado guardado, no solo mediante un cambio visual temporal.

## 5. Eliminar (204)

```http
DELETE /api/tasks/1 HTTP/1.1
Cookie: u2_session=<COOKIE_REAL>
X-CSRF-Token: <TOKEN_CSRF_REAL>
If-Match: "2"
```

Si la versión coincide, responde **204 sin cuerpo**. Si la tarea no existe: 404. Si la versión es antigua: 409. Si se omite `If-Match`: 428.

## 6. Evento en tiempo real (SSE)

La interfaz abre automáticamente una conexión persistente:

```http
GET /api/events HTTP/1.1
Cookie: u2_session=<COOKIE_REAL>
Accept: text/event-stream
```

Ejemplo de mensaje cuando se crea una tarea:

```text
event: task.created
data: {"task":{"id":1,"title":"Preparar exposición","description":"Revisar las diapositivas","status":"pendiente","priority":"alta","dueDate":"2026-12-15","version":1,"createdAt":"<FECHA>","updatedAt":"<FECHA>"},"actor":"Estudiante","type":"task.created"}
```

También se emiten `task.updated` y `task.deleted`. El navegador usa `EventSource`, que vuelve a conectarse automáticamente y actualiza el tablero al reconectarse. No se implementó historial de eventos desconectados; por eso la interfaz vuelve a consultar las tareas después de conectar.

## 7. Códigos HTTP

| HTTP | Código lógico | Caso |
|---|---|---|
| 200 | - | Lectura o edición exitosa |
| 201 | - | Tarea o sesión creada |
| 204 | - | Sesión o tarea eliminada |
| 400 | `INVALID_JSON`, `INVALID_PARAMETER` | JSON o parámetros mal formados |
| 401 | `SESSION_REQUIRED` | Falta sesión activa |
| 403 | `INVALID_CSRF`, `INVALID_ORIGIN` | Acción sin protección válida |
| 404 | `TASK_NOT_FOUND`, `NOT_FOUND` | Recurso o ruta inexistente |
| 405 | `METHOD_NOT_ALLOWED` | Método incorrecto (incluye cabecera Allow) |
| 409 | `TASK_ALREADY_EXISTS`, `VERSION_CONFLICT` | Duplicado o versión obsoleta |
| 413 | `BODY_TOO_LARGE` | JSON mayor que 32 KB |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | Petición sin `application/json` |
| 422 | `VALIDATION_ERROR` | Campos inválidos |
| 428 | `PRECONDITION_REQUIRED` | Falta `If-Match` |

## 8. Probar en Postman

Importa `docs/COLECCION_POSTMAN.json`, ejecuta en orden «Iniciar sesión», «Crear tarea», «Listar tareas», «Consultar tarea», «Editar parcialmente», «Eliminar tarea», «Cerrar sesión». Los scripts de la colección conservan automáticamente la variable CSRF, el identificador y la versión. Postman mantiene las cookies de sesión por dominio. Asegúrate de que `npm start` esté ejecutándose antes de enviar las solicitudes.
