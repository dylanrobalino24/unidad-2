# Capturas para adjuntar antes de la entrega

Las pruebas de API están verificadas en `resultado-pruebas.txt` (17 exitosas). **No se han incluido capturas de interfaz inventadas**. Para obtener evidencias reales:

1. Ejecuta `npm start`, abre `http://localhost:3000` y realiza una captura del formulario de sesión.
2. Entra y crea tres tareas, una por estado. Captura el tablero mostrando las tres columnas y los conteos.
3. Abre dos ventanas del navegador: una normal y otra de incógnito. Entra con distintos nombres. Crea una tarea en una ventana; captura cómo aparece en la otra sin recargar (SSE).
4. En VS Code abre la terminal, ejecuta `npm test` y captura el resumen: `# tests 17`, `# pass 17`, `# fail 0`.
5. Opcional: importa la colección Postman y captura las respuestas 201, 409 y 204.

Puedes añadir estas imágenes a `evidencias/` o al repositorio, sin incluirlas dentro de las dos páginas del informe. Revisa la rúbrica: las evidencias y anexos no cuentan para el límite de páginas.

## Evidencia nueva: marcas ✓ / ✕

- Crea una tarea y toma una captura sin marcar.
- Pulsa ✓ y toma una captura del título en verde.
- Pulsa ✕ en otra tarea y captura el título en rojo.
- Recarga el navegador para verificar que se conservan los estados.
- Abre otra ventana privada, entra con otro nombre y comprueba que el color se actualiza con SSE.
