'use strict';

const $ = (id) => document.getElementById(id);
const labels = {
  pendiente: 'Por hacer', en_progreso: 'En progreso', completada: 'Completada', no_realizada: 'No realizada',
  baja: 'Baja', media: 'Media', alta: 'Alta'
};
const state = { session: null, tasks: [], page: 1, meta: null, editing: null, events: null, refreshTimer: null, toastTimer: null, pendingUpdates: new Set() };

function toast(message, isError = false) {
  const el = $('toast');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.hidden = false;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => { el.hidden = true; }, 4500);
}

async function request(url, { method = 'GET', body, version } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (state.session && !['GET', 'HEAD'].includes(method)) headers['X-CSRF-Token'] = state.session.csrfToken;
  if (version !== undefined) headers['If-Match'] = `"${version}"`;
  let response;
  try {
    response = await fetch(url, { method, headers, credentials: 'same-origin', ...(body !== undefined ? { body: JSON.stringify(body) } : {}) });
  } catch {
    throw new Error('No hay conexión con el servidor.');
  }
  const payload = response.status === 204 ? null : await response.json();
  if (!response.ok) {
    if (response.status === 401) showGate();
    throw new Error(payload?.error?.message || `Error HTTP ${response.status}`);
  }
  return payload;
}

function showGate() {
  state.session = null;
  state.events?.close();
  state.events = null;
  $('workspace').hidden = true;
  $('gate').hidden = false;
  $('connection-label').textContent = 'Sin conexión';
  $('connection-light').classList.remove('online');
}

function showWorkspace() {
  $('gate').hidden = true;
  $('workspace').hidden = false;
  $('user-label').textContent = state.session.name;
  startEvents();
  refresh();
}

function startEvents() {
  state.events?.close();
  const stream = new EventSource('/api/events');
  state.events = stream;
  stream.addEventListener('ready', () => {
    $('connection-label').textContent = 'En tiempo real';
    $('connection-light').classList.add('online');
    scheduleRefresh();
  });
  for (const type of ['task.created', 'task.updated', 'task.deleted']) {
    stream.addEventListener(type, (event) => {
      const data = JSON.parse(event.data);
      if (data.actor !== state.session?.name) toast(`El tablero cambió: ${data.actor}`);
      scheduleRefresh();
    });
  }
  stream.onerror = () => {
    $('connection-label').textContent = 'Reconectando';
    $('connection-light').classList.remove('online');
  };
}

function scheduleRefresh() {
  clearTimeout(state.refreshTimer);
  state.refreshTimer = setTimeout(refresh, 160);
}

function create(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}

function statusClass(status) {
  if (status === 'completada') return 'is-done';
  if (status === 'no_realizada') return 'is-rejected';
  if (status === 'en_progreso') return 'is-progress';
  return 'is-pending';
}

async function markTask(task, status) {
  if (state.pendingUpdates.has(task.id)) return;
  const next = task.status === status ? 'pendiente' : status;
  state.pendingUpdates.add(task.id);
  const selectedRow = document.querySelector(`[data-task-id="${task.id}"]`);
  selectedRow?.querySelectorAll('.mark-button').forEach((button) => { button.disabled = true; });
  try {
    // Solo cambia el estado: PATCH + If-Match, igual que el resto de la API.
    await request(`/api/tasks/${task.id}`, { method: 'PATCH', version: task.version, body: { status: next } });
    toast(next === 'completada' ? 'Tarea marcada como realizada.' : next === 'no_realizada' ? 'Tarea marcada como no realizada.' : 'Tarea devuelta a pendientes.');
    await refresh();
  } catch (error) {
    toast(error.message, true);
    await refresh();
  } finally {
    state.pendingUpdates.delete(task.id);
  }
}

function makeCard(task) {
  const card = create('article', `task-row ${statusClass(task.status)}`);
  card.dataset.taskId = String(task.id);
  const number = create('span', 'row-number', String(task.id).padStart(2, '0'));
  const content = create('div', 'row-content');
  const title = create('h4', 'task-name', task.title);
  const detail = create('p', 'task-description', task.description || 'Sin descripción.');
  const meta = create('div', 'row-meta');
  meta.append(
    create('span', `status-label ${statusClass(task.status)}`, labels[task.status]),
    create('span', '', `${labels[task.priority]} prioridad`),
    create('span', '', task.dueDate ? `Para ${task.dueDate}` : 'Sin fecha límite')
  );
  content.append(title, detail, meta);

  const marks = create('div', 'mark-actions');
  const yes = create('button', 'mark-button mark-yes', '✓');
  yes.type = 'button';
  yes.title = task.status === 'completada' ? 'Volver a pendiente' : 'Marcar como realizada';
  yes.setAttribute('aria-label', `${yes.title}: ${task.title}`);
  yes.setAttribute('aria-pressed', String(task.status === 'completada'));
  yes.addEventListener('click', () => markTask(task, 'completada'));
  const no = create('button', 'mark-button mark-no', '✕');
  no.type = 'button';
  no.title = task.status === 'no_realizada' ? 'Volver a pendiente' : 'Marcar como no realizada';
  no.setAttribute('aria-label', `${no.title}: ${task.title}`);
  no.setAttribute('aria-pressed', String(task.status === 'no_realizada'));
  no.addEventListener('click', () => markTask(task, 'no_realizada'));
  marks.append(yes, no);

  const actions = create('div', 'row-tools');
  const edit = create('button', 'small-action', 'Editar');
  edit.type = 'button';
  edit.setAttribute('aria-label', `Editar ${task.title}`);
  edit.addEventListener('click', () => openDialog(task));
  const remove = create('button', 'small-action danger', 'Borrar');
  remove.type = 'button';
  remove.setAttribute('aria-label', `Eliminar ${task.title}`);
  remove.addEventListener('click', () => deleteTask(task));
  actions.append(edit, remove);
  card.append(number, content, marks, actions);
  return card;
}

function paint() {
  const list = $('list-all');
  list.replaceChildren();
  for (const task of state.tasks) list.append(makeCard(task));
  if (!state.tasks.length) list.append(create('div', 'empty', 'Todavía no hay tareas con este filtro. Pulsa Nueva tarea para empezar.'));
  $('visible-count').textContent = `Mostrando ${state.tasks.length} de ${state.meta?.total ?? 0} tareas filtradas.`;
  $('load-more').hidden = !state.meta || state.page >= state.meta.totalPages;
}

async function refresh() {
  if (!state.session) return;
  try {
    const pages = Array.from({ length: state.page }, (_, index) => index + 1);
    const [lists, summary] = await Promise.all([
      Promise.all(pages.map((page) => {
        const params = new URLSearchParams({ status: $('filter-status').value, q: $('search').value.trim(), page: String(page), limit: '100' });
        return request(`/api/tasks?${params}`);
      })),
      request('/api/summary')
    ]);
    state.tasks = lists.flatMap((list) => list.data);
    state.meta = lists[0].meta;
    $('count-total').textContent = summary.data.total;
    $('count-todo').textContent = summary.data.pendiente;
    $('count-progress').textContent = summary.data.en_progreso;
    $('count-done').textContent = summary.data.completada;
    $('count-rejected').textContent = summary.data.no_realizada;
    paint();
  } catch (error) { toast(error.message, true); }
}

function openDialog(task = null) {
  state.editing = task;
  $('task-form').reset();
  $('dialog-title').textContent = task ? 'Editar tarea' : 'Nueva tarea';
  $('save-task').textContent = task ? 'Guardar cambios' : 'Crear tarea';
  if (task) {
    $('task-title').value = task.title;
    $('task-description').value = task.description;
    $('task-status').value = task.status;
    $('task-priority').value = task.priority;
    $('task-date').value = task.dueDate || '';
  }
  $('task-dialog').showModal();
  $('task-title').focus();
}

async function deleteTask(task) {
  if (!confirm(`¿Eliminar la tarea "${task.title}"? Esta acción no se puede deshacer.`)) return;
  try {
    await request(`/api/tasks/${task.id}`, { method: 'DELETE', version: task.version });
    toast('Tarea eliminada.');
    await refresh();
  } catch (error) { toast(error.message, true); await refresh(); }
}

$('session-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  try {
    state.session = (await request('/api/session', { method: 'POST', body: { name: $('session-name').value } })).data;
    showWorkspace();
  } catch (error) { toast(error.message, true); }
  finally { button.disabled = false; }
});

$('logout-btn').addEventListener('click', async () => {
  try { await request('/api/session', { method: 'DELETE' }); showGate(); }
  catch (error) { toast(error.message, true); }
});
$('new-task').addEventListener('click', () => openDialog());
$('close-dialog').addEventListener('click', () => $('task-dialog').close());
$('cancel-dialog').addEventListener('click', () => $('task-dialog').close());
$('task-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!event.currentTarget.reportValidity()) return;
  const button = $('save-task');
  button.disabled = true;
  const body = {
    title: $('task-title').value,
    description: $('task-description').value,
    status: $('task-status').value,
    priority: $('task-priority').value,
    dueDate: $('task-date').value || null
  };
  try {
    if (state.editing) await request(`/api/tasks/${state.editing.id}`, { method: 'PUT', version: state.editing.version, body });
    else await request('/api/tasks', { method: 'POST', body });
    $('task-dialog').close();
    toast(state.editing ? 'Tarea actualizada.' : 'Tarea creada.');
    await refresh();
  } catch (error) { toast(error.message, true); await refresh(); }
  finally { button.disabled = false; }
});
let searchTimeout;
$('search').addEventListener('input', () => { clearTimeout(searchTimeout); state.page = 1; searchTimeout = setTimeout(refresh, 240); });
$('filter-status').addEventListener('change', () => { state.page = 1; refresh(); });
$('load-more').addEventListener('click', () => { state.page++; refresh(); });

(async function boot() {
  try {
    state.session = (await request('/api/session')).data;
    if (state.session) showWorkspace();
    else showGate();
  } catch (error) { showGate(); toast(error.message, true); }
})();
