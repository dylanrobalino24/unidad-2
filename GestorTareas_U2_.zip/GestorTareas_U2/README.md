# Punto - Gestión de tareas | Aplicaciones Web U2

Proyecto de la **Tarea #1, Unidad 2: Programación del lado del servidor**.

Aplicación completa con **API REST**, **persistencia SQLite**, **sesiones de trabajo con cookie HttpOnly**, **validaciones**, **control de conflictos por versión** y **eventos en tiempo real usando Server-Sent Events (SSE)**. Incluye una interfaz web adaptable a teléfonos y computadoras.

## 1. Requisitos para ejecutar

- **Node.js 22.13 o superior** (se verificó con Node.js 22.16).
- Windows, Linux o macOS.
- Un navegador moderno, por ejemplo Chrome, Edge u Opera.
- **No necesitas** instalar paquetes con `npm install`, crear una base de datos manualmente ni conectarte a Internet.

> Se utiliza el servidor HTTP nativo de Node.js como alternativa funcional a Express, autorizada por la frase «Node.js y Express o una tecnología equivalente» de la consigna. La base SQLite utiliza `node:sqlite`, que en Node 22 muestra un aviso de función experimental. Ese aviso es esperado y no impide ejecutar el proyecto.

## 2. Cómo abrirlo en Windows, paso a paso

1. Descomprime `GestorTareas_U2_Marcas.zip`.
2. Comprueba que Node.js esté instalado. Abre la terminal y ejecuta `node -v`. Debe ser `v22.13.0` o posterior.
3. Abre la carpeta `GestorTareas_U2` en **Visual Studio Code** (Archivo > Abrir carpeta).
4. Ve a **Terminal > Nueva terminal**.
5. Escribe `npm.cmd start` en PowerShell y presiona **Enter** (también sirve `npm start` desde CMD). También puedes hacer doble clic en `iniciar_windows.bat`.
6. Espera el mensaje: `Gestor de tareas disponible en http://localhost:3000`.
7. Abre **http://localhost:3000** en tu navegador.
8. Ingresa un nombre de mínimo 2 caracteres y presiona **Entrar al espacio**.
9. Pulsa **Nueva tarea** y completa el formulario. Pulsa **✓** para marcarla realizada (verde) o **✕** para marcarla no realizada (rojo). Al volver a pulsar la casilla activa, regresa a pendiente. Puedes editar o borrar tareas después.
10. Para comprobar el tiempo real, abre otra ventana de incógnito, entra con otro nombre y crea o edita una tarea; el otro tablero se actualiza.

Para cerrar el servidor, presiona `Ctrl + C` en la terminal.

**Importante:** si ya utilizaste la versión anterior, cierra el servidor y haz una copia de `data/tareas.sqlite` antes de reemplazar archivos. Extrae esta versión sobre la carpeta anterior SIN borrar `data`. La primera ejecución actualiza el esquema sin borrar tareas. La base de datos aparece automáticamente en `data/tareas.sqlite`. Cuando detengas y vuelvas a iniciar el programa, las tareas se conservan. No borres la carpeta `data` si quieres mantenerlas.

## 3. Cómo correr las pruebas

Abre otra terminal dentro del proyecto y ejecuta:

```bash
npm.cmd test
```

**Resultado verificado:** 19 pruebas aprobadas, 0 fallidas. Consulta el resultado en `evidencias/resultado-pruebas.txt` (incluye ✓/✕ y migración de SQLite). La salida real se guarda en `evidencias/resultado-pruebas.txt`. Las pruebas crean una base temporal, no alteran tus tareas reales y comprueban: rutas, sesiones, CSRF, entrada inválida, CRUD, duplicados, filtros, búsqueda parametrizada, códigos HTTP, ETag, conflictos 409, notificación SSE, reabrir SQLite y cierre de sesión.

## 4. Funciones incluidas

- CRUD: `POST`, `GET`, `PUT`, `PATCH` y `DELETE` en `/api/tasks`.
- `GET /api/tasks?status=...&q=...&page=1&limit=50` con parámetros seguros.
- `GET /api/summary` con conteos globales por estado.
- `POST /api/session`, `GET /api/session`, `DELETE /api/session`.
- `GET /api/events` con avisos `task.created`, `task.updated`, `task.deleted`.
- Validación estricta de títulos, descripciones, fechas, prioridad y estado (`pendiente`, `en_progreso`, `completada`, `no_realizada`).
- Códigos HTTP `200`, `201`, `204`, `400`, `401`, `403`, `404`, `405`, `409`, `413`, `415`, `422`, `428`.
- Error uniforme: `{ "error": { "code": "...", "message": "..." } }`.
- Protección CSRF en acciones de escritura, cookie `HttpOnly; SameSite=Strict`, consultas preparadas SQLite.
- Control optimista de concurrencia: enviar la versión del recurso en `If-Match`, y recibir `409 VERSION_CONFLICT` si alguien la modificó.
- Interfaz de lista rústica con casillas ✓ y ✕, título verde/rojo persistente, prioridades, filtro, búsqueda, fechas y diseño adaptable.

**Nota de seguridad:** los nombres introducidos son identificadores de sesión, **no un sistema de autenticación con contraseña**. Todas las tareas pertenecen a un tablero compartido. No se recomienda desplegarlo públicamente con datos sensibles sin agregar autenticación, HTTPS, límites de peticiones y controles adicionales. El servidor se enlaza por defecto solo a `127.0.0.1`.

## 5. Endpoints y ejemplos

La guía detallada está en [`docs/EJEMPLOS_API.md`](docs/EJEMPLOS_API.md). También se proporciona [`docs/COLECCION_POSTMAN.json`](docs/COLECCION_POSTMAN.json) para importar en Postman.

| Método | Ruta | Acción |
|---|---|---|
| GET | `/api/health` | Estado del servidor |
| GET, POST, DELETE | `/api/session` | Consultar, crear, cerrar sesión |
| GET | `/api/summary` | Conteo de tareas |
| GET | `/api/tasks` | Listar y filtrar |
| GET | `/api/tasks/:id` | Consultar una tarea |
| POST | `/api/tasks` | Crear tarea |
| PUT | `/api/tasks/:id` | Reemplazar tarea completa |
| PATCH | `/api/tasks/:id` | Actualizar parcialmente |
| DELETE | `/api/tasks/:id` | Eliminar tarea |
| GET | `/api/events` | Suscribirse a eventos SSE |

## 6. Estructura de carpetas

```text
GestorTareas_U2/
├── src/
│   ├── server.js       # HTTP, rutas, sesiones, SSE
│   ├── database.js     # SQLite y consultas parametrizadas
│   ├── validation.js   # Reglas y funciones puras
│   └── errors.js       # Errores HTTP uniformes
├── public/
│   ├── index.html      # Interfaz web semántica
│   ├── styles.css      # Diseño responsive
│   ├── app.js          # Peticiones fetch y EventSource
│   └── favicon.svg
├── tests/api.test.js   # 19 pruebas automatizadas
├── docs/
│   ├── Apellido_Nombre_AplWeb_U2.pdf  # Informe de máximo 2 páginas
│   ├── INFORME_FUENTE.md             # Texto editable
│   ├── EJEMPLOS_API.md
│   └── COLECCION_POSTMAN.json
├── evidencias/
│   ├── resultado-pruebas.txt
│   └── CAPTURAS_PENDIENTES.md
├── package.json
├── iniciar_windows.bat
└── probar_windows.bat
```

## 7. Qué debes completar antes de entregar

1. Sube el proyecto a tu cuenta de GitHub o a la plataforma indicada por el docente. **La URL no se puede crear desde este archivo.**
2. Sustituye los campos **[Apellido y nombre]**, **[URL del repositorio]** y, si publicas una demostración, **[URL pública de demostración]** en `docs/INFORME_FUENTE.md`.
3. Actualiza el PDF del informe usando esos mismos datos y renómbralo `Apellido_Nombre_AplWeb_U2.pdf` con tus apellidos y nombres reales.
4. Ejecuta `npm test` y toma capturas reales del tablero y de la terminal, según `evidencias/CAPTURAS_PENDIENTES.md`.
5. Entrega el PDF, más el enlace del repositorio, siguiendo las instrucciones del aula virtual.

**Aviso:** el PDF incluido es un borrador técnico completo con campos de identificación y URL sin completar. No lo presentes como si las URL estuvieran publicadas.

## 8. Ajustes opcionales

Si el puerto 3000 está ocupado:

- Windows PowerShell: `$env:PORT=3001; npm start`
- CMD: `set PORT=3001 && npm start`
- Linux/macOS: `PORT=3001 npm start`

Para usar cookie `Secure` detrás de HTTPS, establece `COOKIE_SECURE=1` en el entorno. Esto no activa HTTPS por sí solo.
