@echo off
cd /d "%~dp0"
echo Ejecutando pruebas de API REST...
npm test
pause
