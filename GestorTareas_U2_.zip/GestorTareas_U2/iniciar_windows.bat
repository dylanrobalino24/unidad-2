@echo off
cd /d "%~dp0"
echo Iniciando Punto - Gestor de tareas (Unidad 2)
echo Abre http://localhost:3000 en el navegador.
echo Para detener, presiona Ctrl+C.
npm start
pause
